export const Chain = () => {
	return new Promise((resolve, reject) => {
		resolve();
	});
};
