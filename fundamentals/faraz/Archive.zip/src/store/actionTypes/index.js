export const TEST = `TEST`;

export const ADD_COUNTER = `ADD_COUNTER`;
export const SUBTRACT_COUNTER = `SUBTRACT_COUNTER`;

export const GET_TODOS = `GET_TODOS`;
