const JWT = {
	Key: `123456`
};

export default {
	JWT
};
